﻿=============================
= Setting up Roo and addons =
=============================

Installing the prerequisites - Roo and Maven
============================================

A basic requirement to get started with our Roo addon, is a working installation 
of Roo and Maven.

The easiest way to get both, is to download the "SpringSource Tool Suite" (STS) from SpringSource. STS is an Eclipse-based IDE bundled with Spring technology like Roo.

STS can be downloaded here:

	http://www.springsource.org/sts

After installing STS in a directory of your choice, you will find certain subdirectories there, e.g.

	spring-roo-1.2.1.RELEASE
	apache-maven-3.0.3

Please make sure, that the "bin" directories of these folders are on the path, so that you are able to call the commands "roo" and "mvn" in whichever directory you are on the commandline. (Note: If you are using Linux or Mac then the command to start the Roo Shell is "roo.sh".)

If you are behind a proxy, then please start Roo and issue the command "proxy configuration" on the Roo Shell in order to check if the right HTTP proxy is used by Roo. Information on how to set a proxy in Maven will be given later in this document.

If you have trouble installing STS, Roo, or Maven we would like to refer you to the official websites, where you will find more detailed instructions and a community forum to ask questions.

Websites:
 - STS: http://www.springsource.org/sts
 - Roo: http://www.springsource.org/spring-roo
 - Maven: http://maven.apache.org/
 

Installing the Roo addon
========================

Download and extract the addon package
--------------------------------------

Download the ZIP archive of the addon package: nwcloud-roo-gwaddon-package.zip.

Extract its contents to a folder of your choice. In the following this folder will be called ROO_ADDONS.

Whenever in the following commands or instructions the term ROO_ADDONS is used, please replace the term by the fully qualified path to the directory, where you extracted the contents of the ZIP file.

Install to Roo
--------------

Open a commandline and change to the directory ROO_ADDONS. Once there, execute the following command to install the addon to Roo and set up properly the java application which downloads the metadata at design time.

If you are using Windows:

	install_gwaddon.bat

If you are using Linux or Mac OS:
	chmod +x ./install_gwaddons.sh
	./install_gwaddons.sh
		
Check installation in Roo
-------------------------

Start the Roo Shell and issue the following command to get the list of loaded OSGi bundles in Roo:

	osgi ps

You should see the installed addon at the end of the appearing list, similar to this:
	
	...
	[  75] [Active     ] [    1] nwcloud-roo-gwaddon (1.1.0.RELEASE)
	...
	
If you see a line like this, then the addon has been successfully installed to Roo.

If such a line did not show up in the list, then try to manually install the addon using the following command:

	osgi start --url file:///ROO_ADDONS/com.sap.research.connectivity.gw-1.1.0.RELEASE.jar
	
Hint: If there are any spaces in the path ROO_ADDONS please replace each of them with %20 in this command.

If you ever need to uninstall the addon, then this can be done by the following command on the Roo shell:

	osgi uninstall --bundleSymbolicName com.sap.research.connectivity.gw

Check Metadata Retriever Application
------------------------------------

Go to you user home directory (in Windows it should look something like C:\Users\YourUser\) and check if a file named appToRetrieveOdataMetadata.jar is there. If it is not there, simply copy it from the ROO_ADDONS folder.


And now?
========

Everything should be set up now. If you need to do additional configurations, such as setting the proxy, please refer to the SAP NetWeaver Cloud Addon setup.

© SAP AG, made available under Apache License 2.0
