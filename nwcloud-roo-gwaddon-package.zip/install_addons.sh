#!/bin/bash
echo Installing artifacts to local Roo.
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo - Artifact directory = $DIR

ROO_ADDON_1=com.sap.research.connectivity.gw-1.1.0.RELEASE
ROO_ADDON_1=$DIR/$ROO_ADDON_1.jar

ROO_ADDON_2=appToRetrieveOdataMetadata.jar
ROO_ADDON_2_DEST=$HOME/$ROO_ADDON_2

echo Copying metadata retriever.
cp -i $ROO_ADDON_2 $ROO_ADDON_2_DEST
echo - Done

echo Creating Roo script "install.roo" for installing Roo addons.
echo "osgi start --url file:///${ROO_ADDON_1// /%20}" > install.roo
echo  - Done

echo Execute generated "install.roo" script using Roo.
roo.sh script --file install.roo
echo  - Done